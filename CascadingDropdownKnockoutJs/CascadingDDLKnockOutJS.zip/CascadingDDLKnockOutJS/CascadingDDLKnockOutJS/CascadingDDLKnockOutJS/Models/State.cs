﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CascadingDDLKnockOutJS.Models
{
    public class State
    {
        public string CountryCode { get; set; }
        public int StateId { get; set; }
        public string StateName { get; set; }

        // We can fetch data from any data source here.
        public static List<State> GetStates()
        {
            int stateId = 0;
            return new List<State>
            {
                new State { CountryCode = "IN", StateId = stateId++, StateName = "Gujarat" },
                new State { CountryCode = "IN", StateId = stateId++, StateName = "Delhi" },
                new State { CountryCode = "IN", StateId = stateId++, StateName = "Maharashtra" },
                new State { CountryCode = "US", StateId = stateId++, StateName = "New York" },
                new State { CountryCode = "US", StateId = stateId++, StateName = "California" },
                new State { CountryCode = "US", StateId = stateId++, StateName = "Washington" },
                new State { CountryCode = "UK", StateId = stateId++, StateName = "London" },
                new State { CountryCode = "UK", StateId = stateId++, StateName = "Scotland" },
                new State { CountryCode = "UK", StateId = stateId++, StateName = "Britian" }
            };
        }
    }
}