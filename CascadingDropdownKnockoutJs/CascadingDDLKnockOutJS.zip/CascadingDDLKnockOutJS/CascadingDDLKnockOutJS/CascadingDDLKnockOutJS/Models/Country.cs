﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CascadingDDLKnockOutJS.Models
{
    public class Country
    {
        public string Code { get; set; }
        public string Name { get; set; }

        // We can fetch data from any data source here.
        public static List<Country> GetCountryList()
        {
            return new List<Country>
            {
                new Country { Code = "IN", Name = "India" },
                new Country { Code = "US", Name = "United State" },
                new Country { Code = "UK", Name = "United Kingdom" }
            };
        }
    }
}