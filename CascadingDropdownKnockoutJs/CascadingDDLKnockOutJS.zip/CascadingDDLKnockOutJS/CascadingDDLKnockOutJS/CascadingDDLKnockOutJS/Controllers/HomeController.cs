﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CascadingDDLKnockOutJS.Models;

namespace CascadingDDLKnockOutJS.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Country = new SelectList(Country.GetCountryList(), "Code", "Name");

            return View();
        }

        public ActionResult GetStates(string id = "")
        {
            var stateList = State.GetStates()
                .Where(s => s.CountryCode.ToLower() == id.ToLower());

            return this.Json(stateList, JsonRequestBehavior.AllowGet);
        }
    }
}
